emptylist = False
nextone = True
the_list = []
print("hello! welcome to the list writer.")
print("this program will allow you to create lists.")
while nextone:
    print("press A to add a string to your list. press E to exit. press P to print your list to the console. press S to save your list to this directory. press I to import a list.")
    option = input(" ")
    if option == "a":
        added_string = input("what would you like to add? ")
        the_list.append(added_string)
        print("successfully added string!")
    if option == "p":
        stringed_list = ', '.join(the_list)
        if stringed_list == "":
            print("your list is empty.")
        else:    
            print("your list is: " + stringed_list)
    if option == "e":
        input("are you sure you'd like to exit? all unsaved lists will be lost. ")
        exit()
    if option == "s":
        confirmation = input("this will overwrite any previous save file. are you sure you'd like to continue? (yes/no) ")
        if confirmation.lower() == "yes":
            if len(the_list) > 0:  # Check if my_list contains any elements
                stringed_list_for_save = ', '.join(the_list)
                with open("list.txt", "w") as saved:  # Using 'with' statement for file handling
                    saved.write(stringed_list_for_save)
                print("list successfully saved!")
            else:
                print("error: the list is empty. nothing to save.")
        else:
            print("save operation cancelled.")

    if option == "i":
        def convert(string):
            imported_list = string.split(", ")  # conversion to list
            return imported_list
    
        input("make sure you have a file in this directory named 'list.txt', and press ENTER.")
    
        with open("list.txt", "r") as import2:
            imported_list2 = import2.read()
    
        the_list = convert(imported_list2)  
        print("successfully imported!")

    
        