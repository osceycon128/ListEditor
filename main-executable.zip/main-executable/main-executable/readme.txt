welcome!
if you didn't already catch the warning, this program only works on Windows. not linux, not mac.
if you want the original python file (editable script), go back to the github release page and click on the other file attached. (the one you didn't download.) this will give you access to the original code for the project.
head over to the ListEditor.exe program in this folder to get started.

